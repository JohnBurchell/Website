Controls:

Left : Move left
Right : Move right
Up : rotate
Down : Move down a row
Space: Send to bottom

To turn off the music, press escape, options and click the button to enable / disable music.
